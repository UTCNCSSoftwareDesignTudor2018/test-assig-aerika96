
public interface CreateVehicle {

	public void create();
}

