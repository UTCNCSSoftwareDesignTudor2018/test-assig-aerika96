

public class Boat extends Vehicle{
	
	public Boat (){
		this.rideOn = Surface.WATER;
		this.price = 600000.599;
	}

}
