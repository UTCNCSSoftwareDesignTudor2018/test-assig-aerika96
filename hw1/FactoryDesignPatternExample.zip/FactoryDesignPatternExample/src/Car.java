
public class Car extends Vehicle{

	public Car(){
		this.rideOn = Surface.LAND;
		this.price= 5000.50;
	}
	
}
