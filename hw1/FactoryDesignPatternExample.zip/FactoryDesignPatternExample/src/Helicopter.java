
public class Helicopter extends Vehicle {

	public Helicopter(){
		this.rideOn = Surface.AIR;
		this.price = 40000.2365;
		
	}
}
